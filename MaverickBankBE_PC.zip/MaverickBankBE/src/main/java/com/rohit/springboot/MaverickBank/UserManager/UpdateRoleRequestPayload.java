package com.rohit.springboot.MaverickBank.UserManager;

import lombok.Data;

@Data
public class UpdateRoleRequestPayload {
    private String Username;
    private String Role;
}

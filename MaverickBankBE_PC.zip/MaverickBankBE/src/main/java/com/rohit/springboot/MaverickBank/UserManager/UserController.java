package com.rohit.springboot.MaverickBank.UserManager;

import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import com.rohit.springboot.MaverickBank.security.Jwt.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;


@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody UpdateUserPayload updateUserPayload){

        try{
            User user = userRepository.findByEmailOrPhonenumberOrPan(updateUserPayload.getUsername(),updateUserPayload.getUsername(),updateUserPayload.getUsername());
            if(updateUserPayload.getEmail()!=null){
                user.setEmail(updateUserPayload.getEmail());
            }
            if(updateUserPayload.getPhonenumber()!=null){
                user.setPhonenumber(updateUserPayload.getPhonenumber());
            }
            if(updateUserPayload.getPan()!=null){
                user.setPan(updateUserPayload.getPan());
            }
            if(updateUserPayload.getFullname()!=null){
                user.setFullname(updateUserPayload.getFullname());
            }
            if(updateUserPayload.getDob()!=null){
                user.setDob(updateUserPayload.getDob());
            }
            if(updateUserPayload.getAddress()!=null){
                user.setAddress(updateUserPayload.getAddress());
            }

            userRepository.save(user);

            return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
        }catch(Error e) {
            return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
        }

    }

    @PostMapping("/updateRole")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<?> updateUserRole(@RequestBody UpdateRoleRequestPayload updateRoleRequestPayload){

        if(!Objects.equals(updateRoleRequestPayload.getRole(), "ADMIN") && !Objects.equals(updateRoleRequestPayload.getRole(), "EMPLOYEE") && !Objects.equals(updateRoleRequestPayload.getRole(), "USER") ){
            return new ResponseEntity<>("Wrong Role value",HttpStatus.BAD_REQUEST);
        }

        User user =userRepository.findByEmailOrPhonenumberOrPan(updateRoleRequestPayload.getUsername(),updateRoleRequestPayload.getUsername(),updateRoleRequestPayload.getUsername());

        user.setRole(updateRoleRequestPayload.getRole());

        userRepository.save(user);


        return new ResponseEntity<>("Role setted :"+updateRoleRequestPayload.getRole(),HttpStatus.BAD_REQUEST);
    }


}

package com.rohit.springboot.MaverickBank.Authentication;

import lombok.Data;

@Data
public class LoginRequestPayload {
    private String username;
    private String password;
}

package com.rohit.springboot.MaverickBank.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Character type;


    @Column(nullable = false)
    private Float amount;

    @Column(nullable = false,updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Timestamp time;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="owner_account",nullable = false)
    private Account transaction_owner;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="receiver_account")
    private Account transaction_receiver;


}

package com.rohit.springboot.MaverickBank.Payload;

import lombok.Data;

@Data
public class MakeAccountDto {
    private Character type;
    private Long owner_id;
    private Long branch_id;
}

package com.rohit.springboot.MaverickBank.Authentication;

import lombok.*;

@Data
public class LoginResponsePayload {
    private String token;
    private String type = "Bearer";
    private Long id;
    private String username;
    private String roles;

    public LoginResponsePayload(String accessToken, Long id, String username, String roles) {
        this.token = accessToken;
        this.id = id;
        this.username = username;
        this.roles = roles;
    }

}



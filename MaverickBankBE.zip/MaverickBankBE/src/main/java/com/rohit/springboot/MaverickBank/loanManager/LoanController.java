package com.rohit.springboot.MaverickBank.loanManager;

import com.rohit.springboot.MaverickBank.entities.Account;
import com.rohit.springboot.MaverickBank.entities.ApprovedLoan;
import com.rohit.springboot.MaverickBank.entities.LoanRequest;
import com.rohit.springboot.MaverickBank.loanManager.requestPayload.AproveLoanRequestPayload;
import com.rohit.springboot.MaverickBank.loanManager.requestPayload.GetLoanRequestPayload;
import com.rohit.springboot.MaverickBank.loanManager.requestPayload.LoanRequestPayload;
import com.rohit.springboot.MaverickBank.repository.AccountRepository;
import com.rohit.springboot.MaverickBank.repository.ApprovedLoanRepository;
import com.rohit.springboot.MaverickBank.repository.LoanRequestsRepository;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/loan")
public class LoanController {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    ApprovedLoanRepository approvedLoanRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LoanRequestsRepository loanRequestsRepository;

    @PostMapping("/request")
    @PreAuthorize("hasAnyAuthority('USER')")
    public ResponseEntity<?> requestLoan(@RequestBody LoanRequestPayload request){
        try{
            LoanRequest loanRequest =new LoanRequest();

            loanRequest.setAmount(request.getAmount());
            loanRequest.setType(request.getType());
            loanRequest.setTerm(request.getTerm());
            loanRequest.setInterest(request.getIntrest());
            loanRequest.setRequester_account(accountRepository.findById(request.getAccountid()).get());

            loanRequestsRepository.save(loanRequest);

            return new ResponseEntity<>("Loan requested", HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>("some error occured",HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/approve")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<?> approveLoan(@RequestBody AproveLoanRequestPayload request){
        try{
            LoanRequest loanRequest =loanRequestsRepository.findById(request.getRequestid()).get();

            ApprovedLoan loan =new ApprovedLoan();
            loan.setAmount(loanRequest.getAmount());
            loan.setType(loanRequest.getType());
            loan.setTerm(loanRequest.getTerm());
            loan.setInterest(loanRequest.getInterest());
            loan.setBorrower_account(accountRepository.findById(loanRequest.getRequester_account().getId()).get());
            loan.setAmountleft(loan.getAmount());
            loan.setApprover_id(userRepository.findById(request.getAproverid()).get());
            loan.setStartdate(new Date());
            loanRequestsRepository.delete(loanRequest);
            approvedLoanRepository.save(loan);

            return new ResponseEntity<>("Loan Aproved", HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>("some error occured",HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/getLoanRequest")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    @ResponseBody
    public List<LoanRequest> getLoanRequests(){
        List<LoanRequest> requests = loanRequestsRepository.findAll();
        return requests;
    }

}

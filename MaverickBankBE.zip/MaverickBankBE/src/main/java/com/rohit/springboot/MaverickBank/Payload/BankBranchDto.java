package com.rohit.springboot.MaverickBank.Payload;

import lombok.Data;

@Data
public class BankBranchDto {
    private String city="";
    private String ifsc="";
    private String pincode="";
    private Long id = -1L;
}

package com.rohit.springboot.MaverickBank.authentication.responsePayload;

public class SignupResponsePayload {
}

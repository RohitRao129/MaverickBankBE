package com.rohit.springboot.MaverickBank.Authentication;

public class UpdateUserPayload {
}

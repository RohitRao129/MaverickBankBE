package com.rohit.springboot.MaverickBank.accountManager.requesPayload;

import lombok.Data;

@Data
public class AccountIdPayload {
   private  String Account_id;
}

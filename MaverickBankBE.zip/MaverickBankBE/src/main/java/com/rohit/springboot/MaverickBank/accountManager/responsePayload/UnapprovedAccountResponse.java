package com.rohit.springboot.MaverickBank.accountManager.responsePayload;

import com.rohit.springboot.MaverickBank.entities.Account;
import lombok.Data;

import java.util.List;

@Data
public class UnapprovedAccountResponse {

private List<Account> unapprovedAccounts;

public UnapprovedAccountResponse(List<Account> accounts){
    this.unapprovedAccounts =accounts;
}

}

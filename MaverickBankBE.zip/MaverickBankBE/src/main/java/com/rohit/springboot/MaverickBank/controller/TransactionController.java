package com.rohit.springboot.MaverickBank.controller;

import com.rohit.springboot.MaverickBank.entities.Transaction;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.TransactionRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TransactionController {

    private TransactionRepository transactionRepository;
    @GetMapping("/getTransactions")
    public  List<Transaction> findAllTransactions(){
        return transactionRepository.findAll();
    }
}

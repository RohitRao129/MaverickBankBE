package com.rohit.springboot.MaverickBank.Authentication;

import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import com.rohit.springboot.MaverickBank.security.Jwt.JwtUtils;
import com.rohit.springboot.MaverickBank.security.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@EnableWebSecurity
@EnableMethodSecurity
@RestController
@RequestMapping("/auth")
public class AuthenticationController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/signUp")
    public ResponseEntity<?> addUser(@RequestBody SignupRequestPayload signupRequestPayload){

        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

        User existinguser = userRepository.findByEmail(signupRequestPayload.getEmail());
        if(existinguser!=null){
            return new ResponseEntity<>("Email already registered", HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPhonenumber(signupRequestPayload.getPhonenumber());
        if(existinguser!=null){
            return new ResponseEntity<>("Phone already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPan(signupRequestPayload.getPan());
        if(existinguser!=null){
            return new ResponseEntity<>("PAN already registered",HttpStatus.BAD_REQUEST);
        }

        String encodedPassword = bCryptPasswordEncoder.encode(signupRequestPayload.getPassword());

        User user = new User();
        user.setFullname(signupRequestPayload.getFullname());
        user.setEmail(signupRequestPayload.getEmail());
        user.setPhonenumber(signupRequestPayload.getPhonenumber());
        user.setPassword(encodedPassword);
        user.setPan(signupRequestPayload.getPan());
        user.setDob(signupRequestPayload.getDob());
        user.setAddress(signupRequestPayload.getAddress());
        user.setRole("USER");
        userRepository.save(user);

        return new ResponseEntity<>("User registered successfully", HttpStatus.OK);

    }

    @PostMapping("/AdminSignUp")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<?> addAdmin(@RequestBody SignupRequestPayload signupRequestPayload){

        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

        User existinguser = userRepository.findByEmail(signupRequestPayload.getEmail());
        if(existinguser!=null){
            return new ResponseEntity<>("Email already registered", HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPhonenumber(signupRequestPayload.getPhonenumber());
        if(existinguser!=null){
            return new ResponseEntity<>("Phone already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPan(signupRequestPayload.getPan());
        if(existinguser!=null){
            return new ResponseEntity<>("PAN already registered",HttpStatus.BAD_REQUEST);
        }

        String encodedPassword = bCryptPasswordEncoder.encode(signupRequestPayload.getPassword());

        User user = new User();
        user.setFullname(signupRequestPayload.getFullname());
        user.setEmail(signupRequestPayload.getEmail());
        user.setPhonenumber(signupRequestPayload.getPhonenumber());
        user.setPassword(encodedPassword);
        user.setPan(signupRequestPayload.getPan());
        user.setDob(signupRequestPayload.getDob());
        user.setAddress(signupRequestPayload.getAddress());
        user.setRole("ADMIN");
        userRepository.save(user);

        return new ResponseEntity<>("Admin registered successfully", HttpStatus.OK);

    }

    @PostMapping("/EmployeeSignUp")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<?> addEmployee(@RequestBody SignupRequestPayload signupRequestPayload){

        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

        User existinguser = userRepository.findByEmail(signupRequestPayload.getEmail());
        if(existinguser!=null){
            return new ResponseEntity<>("Email already registered", HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPhonenumber(signupRequestPayload.getPhonenumber());
        if(existinguser!=null){
            return new ResponseEntity<>("Phone already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPan(signupRequestPayload.getPan());
        if(existinguser!=null){
            return new ResponseEntity<>("PAN already registered",HttpStatus.BAD_REQUEST);
        }

        String encodedPassword = bCryptPasswordEncoder.encode(signupRequestPayload.getPassword());

        User user = new User();
        user.setFullname(signupRequestPayload.getFullname());
        user.setEmail(signupRequestPayload.getEmail());
        user.setPhonenumber(signupRequestPayload.getPhonenumber());
        user.setPassword(encodedPassword);
        user.setPan(signupRequestPayload.getPan());
        user.setDob(signupRequestPayload.getDob());
        user.setAddress(signupRequestPayload.getAddress());
        user.setRole("EMPLOYEE");
        userRepository.save(user);

        return new ResponseEntity<>("Admin registered successfully", HttpStatus.OK);

    }

    @GetMapping("/getAllUsers")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public List<User> findAllUsers(){
        return userRepository.findAll();
    }


    @ResponseBody
    @PostMapping("/signIn")
    public ResponseEntity<?> Login(@RequestBody LoginRequestPayload loginRequestPayload){

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequestPayload.getUsername(), loginRequestPayload.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        String roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .toList().get(0);

        return ResponseEntity.ok(new LoginResponsePayload(jwt,
                userDetails.getId(),
                userDetails.getUsername(),
                roles));
    }

    @ResponseBody
    @PostMapping("/updateUser")
    private ResponseEntity<?> updateUser(@RequestBody SignupRequestPayload signupRequestPayload){
        return  new ResponseEntity<>("hihihi",HttpStatus.OK);
    }



}

package com.rohit.springboot.MaverickBank.accountManager;

import com.rohit.springboot.MaverickBank.accountManager.requesPayload.ApproveAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.requesPayload.GetUnapprovedAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.requesPayload.MakeAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.responsePayload.UnapprovedAccountResponse;
import com.rohit.springboot.MaverickBank.entities.Account;
import com.rohit.springboot.MaverickBank.entities.BankBranch;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.AccountRepository;
import com.rohit.springboot.MaverickBank.repository.BankBranchRepository;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/account")
public class AccountController {

    private BankBranchRepository bankBranchRepository;
    private AccountRepository accountRepository;

    private UserRepository userRepository;

    public String setpin(){
        String pincontainer ="0123456789";
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 4; i++) {
            int index = (int)(pincontainer.length() * Math.random());
            sb.append(pincontainer.charAt(index));
        }

        return  sb.toString();
    }

    @PostMapping("/create")
    public  ResponseEntity<?> createAccount(MakeAccountRequestPayload request){
        User owner = userRepository.findById(request.getOwner_id()).get();
        BankBranch branch = bankBranchRepository.findById(request.getBranch_id()).get();

        return new ResponseEntity<>("account creation application submitted",HttpStatus.OK);
    }

    @PostMapping("/approve")
    @PreAuthorize("harAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<String> approveAccount(ApproveAccountRequestPayload request){


        Optional<Account> account =accountRepository.findById(Long.parseLong(request.getAccount_id()));
        if(account.isEmpty()){
            return  new ResponseEntity<>("account not found!",HttpStatus.BAD_REQUEST);
        }

        account.get().setApproved(true);

        accountRepository.save(account.get());
        return new ResponseEntity<>("Account Creation Approved", HttpStatus.OK);

    }

    @PostMapping("/getApproveRequests")
    @PreAuthorize("harAnyAuthority('ADMIN','EMPLOYEE')")
    @ResponseBody
    public ResponseEntity<?> GetAllApproveRequsets(GetUnapprovedAccountRequestPayload request){

        List<Account> accounts =accountRepository.findAllByIfsc(request.getIfsc());
        if(accounts.isEmpty()){
            return  new ResponseEntity<>("No unapproved accounts here",HttpStatus.BAD_REQUEST);
        }

        return ResponseEntity.ok(new UnapprovedAccountResponse(accounts));

    }





}

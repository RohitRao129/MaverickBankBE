package com.rohit.springboot.MaverickBank.accountManager;

import com.rohit.springboot.MaverickBank.accountManager.requesPayload.ApproveAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.requesPayload.GetAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.requesPayload.GetUnapprovedAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.requesPayload.MakeAccountRequestPayload;
import com.rohit.springboot.MaverickBank.accountManager.responsePayload.UnapprovedAccountResponse;
import com.rohit.springboot.MaverickBank.entities.Account;
import com.rohit.springboot.MaverickBank.entities.BankBranch;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.AccountRepository;
import com.rohit.springboot.MaverickBank.repository.BankBranchRepository;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/account")
public class AccountController {

    @Autowired
    private BankBranchRepository bankBranchRepository;
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    public String setpin(){
        String pincontainer ="0123456789";
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 4; i++) {
            int index = (int)(pincontainer.length() * Math.random());
            sb.append(pincontainer.charAt(index));
        }

        return  sb.toString();
    }

    @PostMapping("/create")
    public  ResponseEntity<?> createAccount(@RequestBody MakeAccountRequestPayload request){
        User owner = userRepository.findByEmailOrPhonenumberOrPan(request.getUsername(),request.getUsername(), request.getUsername());
        BankBranch branch = bankBranchRepository.findById(request.getBranchid()).get();

        List<User> owners =new ArrayList<>();owners.add(owner);

        Account accountrequest = new Account();
        accountrequest.setAccount_owners(owners);
        accountrequest.setBalance(0f);
        accountrequest.setCreationdate(new Date());
        accountrequest.setPin(setpin());
        accountrequest.setIfsc(branch.getIfsc());
        accountrequest.setBranch(branch.getCity());
        accountrequest.setApproved(false);
        accountRepository.save(accountrequest);

        return new ResponseEntity<>("account creation application submitted",HttpStatus.OK);
    }

    @PostMapping("/get")
    @ResponseBody
    public  List<Account> getAccountOfUser(@RequestBody GetAccountRequestPayload request){
        User user =userRepository.findByEmailOrPhonenumberOrPan(request.getUsername(),request.getUsername(),request.getUsername());
        return  user.getAccounts();
    }

    @PostMapping("/approve")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<String> approveAccount(@RequestBody ApproveAccountRequestPayload request){


        Optional<Account> account =accountRepository.findById(Long.parseLong(request.getAccount_id()));
        if(account.isEmpty()){
            return  new ResponseEntity<>("account not found!",HttpStatus.BAD_REQUEST);
        }

        account.get().setApproved(true);

        accountRepository.save(account.get());
        return new ResponseEntity<>("Account Creation Approved", HttpStatus.OK);

    }

    @PostMapping("/getApproveRequests")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    @ResponseBody
    public UnapprovedAccountResponse GetAllApproveRequsets(@RequestBody GetUnapprovedAccountRequestPayload request){

        List<Account> accounts =accountRepository.findAllByIfscAndApproved(request.getIfsc(),false);

        return new UnapprovedAccountResponse(accounts);

    }





}

package com.rohit.springboot.MaverickBank.loanManager.requestPayload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.security.PublicKey;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoanRequestPayload {
    public Long accountid;
    public float amount;
    public float intrest;
    public Integer term;
    public String type;
}

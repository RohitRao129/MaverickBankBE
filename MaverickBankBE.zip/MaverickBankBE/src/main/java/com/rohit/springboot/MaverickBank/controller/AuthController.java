package com.rohit.springboot.MaverickBank.controller;


import com.rohit.springboot.MaverickBank.dto.LoginDTO;
import com.rohit.springboot.MaverickBank.dto.LoginResponse;
import com.rohit.springboot.MaverickBank.dto.SignUpDto;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import com.rohit.springboot.MaverickBank.security.Jwt.JwtUtils;
import com.rohit.springboot.MaverickBank.security.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:8081", maxAge = 3600, allowCredentials="true")
public class AuthController {


    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/signup")
    public ResponseEntity<?>  addUser(@RequestBody SignUpDto signUpDto){

        User existinguser = userRepository.findByEmail(signUpDto.getEmail());
        if(existinguser!=null){
            return new ResponseEntity<>("Email already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPhonenumber(signUpDto.getPhonenumber());
        if(existinguser!=null){
            return new ResponseEntity<>("Phone already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPan(signUpDto.getPan());
        if(existinguser!=null){
            return new ResponseEntity<>("PAN already registered",HttpStatus.BAD_REQUEST);
        }


        User user = new User();
        user.setFullname(signUpDto.getFullname());
        user.setEmail(signUpDto.getEmail());
        user.setPhonenumber(signUpDto.getPhonenumber());
        user.setPassword(signUpDto.getPassword());
        user.setPan(signUpDto.getPan());
        user.setDob(signUpDto.getDob());
        user.setAddress(signUpDto.getAddress());
        userRepository.save(user);

        return new ResponseEntity<>("User registered successfully", HttpStatus.OK);

    }

    @GetMapping("/getallusers")
    public  List<User> findAllUsers(){
        return userRepository.findAll();
    }


    @ResponseBody
    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginDTO loginDto){

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        String roles = userDetails.getAuthorities().stream()
                .map(item -> item.getAuthority())
                .toList().get(0);

        return ResponseEntity.ok(new LoginResponse(jwt,
                userDetails.getId(),
                userDetails.getUsername(),
                userDetails.getUsername(),
                roles));
    }
}

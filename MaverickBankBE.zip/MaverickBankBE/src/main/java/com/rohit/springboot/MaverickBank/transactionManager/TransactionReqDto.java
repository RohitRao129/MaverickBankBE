package com.rohit.springboot.MaverickBank.transactionManager;

import lombok.Data;

@Data
public class TransactionReqDto {
    private Long id;
    private String pin;
    private Float amount;
    private Long owner_account;
    private Long receiver_account;
    private String ifsc;
}

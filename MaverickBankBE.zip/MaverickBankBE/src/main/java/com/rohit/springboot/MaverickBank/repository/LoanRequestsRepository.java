package com.rohit.springboot.MaverickBank.repository;

import com.rohit.springboot.MaverickBank.entities.LoanRequest;
import com.rohit.springboot.MaverickBank.entities.LoanRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanRequestsRepository extends JpaRepository<LoanRequest,Long> {
}

package com.rohit.springboot.MaverickBank.controller;

import com.rohit.springboot.MaverickBank.dto.MakeAccountDto;
import com.rohit.springboot.MaverickBank.entities.Account;
import com.rohit.springboot.MaverickBank.entities.BankBranch;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.AccountRepository;
import com.rohit.springboot.MaverickBank.repository.BankBranchRepository;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
@RequestMapping("/account")
public class AccountController {

    private BankBranchRepository bankBranchRepository;
    private AccountRepository accountRepository;

    private UserRepository userRepository;

    @PostMapping("/create")
    public ResponseEntity<String> createAccount(MakeAccountDto makeAccountDto){

        Optional<BankBranch> branch = bankBranchRepository.findById(makeAccountDto.getBranch_id());

        Account account =new Account();
        account.setType(makeAccountDto.getType());
        account.setBranch(branch.get().getCity());
        account.setIfsc(branch.get().getIfsc());

        List<User> owners= new ArrayList<>();
        owners.add(userRepository.findById(makeAccountDto.getOwner_id()).get());
        account.setAccount_owners( owners);


        String pincontainer ="0123456789";
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 4; i++) {
            int index = (int)(pincontainer.length() * Math.random());
            sb.append(pincontainer.charAt(index));
        }
        account.setPin(sb.toString());

        return new ResponseEntity<>("Account Creation Requested", HttpStatus.OK);

    }


}

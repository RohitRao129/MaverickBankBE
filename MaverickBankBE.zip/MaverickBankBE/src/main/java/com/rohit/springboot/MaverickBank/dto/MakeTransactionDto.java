package com.rohit.springboot.MaverickBank.dto;

import lombok.Data;

@Data
public class MakeTransactionDto {
    private Character type;
    private Float amount;
    private Long owner_account;
    private Long receiver_account;
}

package com.rohit.springboot.MaverickBank.dto;

import com.rohit.springboot.MaverickBank.entities.User;
import lombok.Data;

import java.util.List;

@Data
public class MakeAccountDto {
    private Character type;
    private Long owner_id;
    private Long branch_id;
}

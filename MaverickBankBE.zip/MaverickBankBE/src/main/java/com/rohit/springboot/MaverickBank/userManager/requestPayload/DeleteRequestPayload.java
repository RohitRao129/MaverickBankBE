package com.rohit.springboot.MaverickBank.userManager.requestPayload;

import lombok.Data;

@Data
public class DeleteRequestPayload {
    private String Username;
}

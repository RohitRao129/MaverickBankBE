package com.rohit.springboot.MaverickBank.entities;


import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @Column(nullable = false)
    private boolean approved =false;

    @Column(nullable = false)
    private Character type;

    @Column(nullable = false,updatable = false)
    @Temporal(TemporalType.DATE)
    @CreatedDate
    private Date creationdate;

    @Column()
    private Date closedate;

    @Column(nullable = false)
    private String ifsc;

    @Column(nullable = false)
    private String branch;

    @Column(nullable = false,columnDefinition = "float default 0")
    private Float balance;

    @Column(nullable = false,length = 4)
    private String pin;

    @ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinTable(
            name = "accounts_users",
            joinColumns = {@JoinColumn(name = "account_id",referencedColumnName = "ID")},
            inverseJoinColumns = {@JoinColumn(name ="user_id",referencedColumnName = "ID")})
    private List<User> account_owners =new ArrayList<>();

    //mapped by is the name of variable your made in other table you're mapping.
    @OneToMany(mappedBy = "transaction_owner",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private Set<Transaction> transactions_Owner;

    @OneToMany(mappedBy = "transaction_receiver",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private Set<Transaction> transactions_receiver;



    @OneToMany(mappedBy = "requester_account",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private Set<LoanRequest> loan_requester;

    @OneToMany(mappedBy = "borrower_account",fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    private Set<ApprovedLoan> borrower;



}

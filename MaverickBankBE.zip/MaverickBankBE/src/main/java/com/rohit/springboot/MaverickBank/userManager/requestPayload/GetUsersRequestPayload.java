package com.rohit.springboot.MaverickBank.userManager.requestPayload;

import lombok.Data;

@Data
public class GetUsersRequestPayload {
    private Long Id=null;
    private String username=null;

    private String Ifsc=null;

}

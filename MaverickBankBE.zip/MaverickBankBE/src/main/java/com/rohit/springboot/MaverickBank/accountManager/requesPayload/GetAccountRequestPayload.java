package com.rohit.springboot.MaverickBank.accountManager.requesPayload;

import lombok.Data;

@Data
public class GetAccountRequestPayload {
    private String username;
}

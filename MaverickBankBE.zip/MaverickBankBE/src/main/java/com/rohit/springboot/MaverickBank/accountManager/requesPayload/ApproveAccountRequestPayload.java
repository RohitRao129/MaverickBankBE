package com.rohit.springboot.MaverickBank.accountManager.requesPayload;

import lombok.Data;

@Data
public class ApproveAccountRequestPayload {
   private  String Account_id;
}

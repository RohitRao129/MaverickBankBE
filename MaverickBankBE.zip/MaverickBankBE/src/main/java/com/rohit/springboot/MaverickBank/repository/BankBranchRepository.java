package com.rohit.springboot.MaverickBank.repository;

import com.rohit.springboot.MaverickBank.entities.BankBranch;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BankBranchRepository extends JpaRepository<BankBranch,Long> {
    List<BankBranch> findAllByCityOrIfsc(String query, String query1);

    BankBranch findByIfsc(String ifsc);

    BankBranch findByPincode(String pincode);
}

package com.rohit.springboot.MaverickBank.entities;

public enum Role {
    USER,
    EMPLOYEE,
    ADMIN
}

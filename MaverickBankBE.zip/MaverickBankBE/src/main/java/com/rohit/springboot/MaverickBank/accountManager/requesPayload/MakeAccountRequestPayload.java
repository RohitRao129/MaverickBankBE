package com.rohit.springboot.MaverickBank.accountManager.requesPayload;

import lombok.Data;

@Data
public class MakeAccountRequestPayload {
    private Character type;
    private Long owner_id;
    private Long branch_id;
}

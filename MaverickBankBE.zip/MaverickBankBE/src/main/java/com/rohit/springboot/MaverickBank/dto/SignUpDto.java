package com.rohit.springboot.MaverickBank.dto;

import lombok.Data;

import java.util.Date;

@Data
public class SignUpDto {
    private String fullname;
    private String phonenumber;
    private String email;
    private String password;
    private String address;
    private String pan;
    private Date dob;
    private Character role;
}

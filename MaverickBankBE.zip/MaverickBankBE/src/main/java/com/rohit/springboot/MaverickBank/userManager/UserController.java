package com.rohit.springboot.MaverickBank.userManager;

import com.rohit.springboot.MaverickBank.authentication.responsePayload.LoginResponsePayload;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import com.rohit.springboot.MaverickBank.security.Jwt.JwtUtils;
import com.rohit.springboot.MaverickBank.security.UserDetailsImpl;
import com.rohit.springboot.MaverickBank.userManager.requestPayload.DeleteRequestPayload;
import com.rohit.springboot.MaverickBank.userManager.requestPayload.GetUsersRequestPayload;
import com.rohit.springboot.MaverickBank.userManager.requestPayload.UpdateRoleRequestPayload;
import com.rohit.springboot.MaverickBank.userManager.requestPayload.UpdateUserPayload;
import com.rohit.springboot.MaverickBank.userManager.responsePayload.GetUsersResponsePayload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/get")
    public User getuser(@RequestBody GetUsersRequestPayload request){
        User user =null;
        if(request.getId()!=null)
        {user =userRepository.findById(request.getId()).get();}

        if(request.getUsername()!=null && user==null){
            user =userRepository.findByEmailOrPhonenumberOrPan(request.getUsername(),request.getUsername(),request.getUsername());
        }

        return user;
    }

    @GetMapping("/getAll")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    @ResponseBody
    public GetUsersResponsePayload findAllUsers(){
        return new GetUsersResponsePayload(userRepository.findAll()
        );
    }

    @PostMapping("/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody UpdateUserPayload updateUserPayload){

        try{
            User user = userRepository.findByEmailOrPhonenumberOrPan(updateUserPayload.getUsername(),updateUserPayload.getUsername(),updateUserPayload.getUsername());
            if(updateUserPayload.getEmail()!=null){
                if(userRepository.findByEmail(updateUserPayload.getEmail())!=null)
                {return new ResponseEntity<>("email already registered",HttpStatus.BAD_REQUEST);}
                user.setEmail(updateUserPayload.getEmail());
            }
            if(updateUserPayload.getPhonenumber()!=null){
                if(userRepository.findByPhonenumber(updateUserPayload.getPhonenumber())!=null)
                {return new ResponseEntity<>("Phone number already registered",HttpStatus.BAD_REQUEST);}

                user.setPhonenumber(updateUserPayload.getPhonenumber());
            }
            if(updateUserPayload.getPan()!=null){
                if(userRepository.findByPan(updateUserPayload.getPan())!=null)
                {return new ResponseEntity<>("Pan already registered",HttpStatus.BAD_REQUEST);}


                user.setPan(updateUserPayload.getPan());
            }
            if(updateUserPayload.getFullname()!=null){
                user.setFullname(updateUserPayload.getFullname());
            }
            if(updateUserPayload.getDob()!=null){
                user.setDob(updateUserPayload.getDob());
            }
            if(updateUserPayload.getAddress()!=null){
                user.setAddress(updateUserPayload.getAddress());
            }

            userRepository.save(user);


            return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
        }catch(Error e) {
            return new ResponseEntity<String>(e.toString(), HttpStatus.BAD_REQUEST);
        }

    }

    @PostMapping("/updateRole")
    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public ResponseEntity<?> updateUserRole(@RequestBody UpdateRoleRequestPayload updateRoleRequestPayload){

        if(!Objects.equals(updateRoleRequestPayload.getRole(), "ADMIN") && !Objects.equals(updateRoleRequestPayload.getRole(), "EMPLOYEE") && !Objects.equals(updateRoleRequestPayload.getRole(), "USER") ){
            return new ResponseEntity<>("Wrong Role value",HttpStatus.BAD_REQUEST);
        }

        User user =userRepository.findByEmailOrPhonenumberOrPan(updateRoleRequestPayload.getUsername(),updateRoleRequestPayload.getUsername(),updateRoleRequestPayload.getUsername());

        user.setRole(updateRoleRequestPayload.getRole());

        userRepository.save(user);

        return new ResponseEntity<>(user.getEmail()+" now has the role :"+updateRoleRequestPayload.getRole(),HttpStatus.OK);
    }

    @PostMapping("/delete/user")
    public ResponseEntity<?> deleteUser(@RequestBody DeleteRequestPayload deleteRequestPayload){
        User user = userRepository.findByEmailOrPhonenumberOrPan(deleteRequestPayload.getUsername(),deleteRequestPayload.getUsername(),deleteRequestPayload.getUsername());

        if(user==null)return  new ResponseEntity<>("No user found!",HttpStatus.BAD_REQUEST);

        if(Objects.equals(user.getRole(), "ADMIN") || Objects.equals(user.getRole(),"EMPLOYEE")){
            return  new ResponseEntity<>("admin or employeecant be delete at this url!",HttpStatus.BAD_REQUEST);
        }

        userRepository.delete(user);

        return  new ResponseEntity<>("User Deleted!",HttpStatus.OK);

    }

    @PostMapping("/delete/adminOrEmployee")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<?> deleteEmployeeOrAdmin(@RequestBody DeleteRequestPayload deleteRequestPayload){
        User user = userRepository.findByEmailOrPhonenumberOrPan(deleteRequestPayload.getUsername(),deleteRequestPayload.getUsername(),deleteRequestPayload.getUsername());

        if(user==null)return  new ResponseEntity<>("No user found!",HttpStatus.BAD_REQUEST);

        userRepository.delete(user);

        return  new ResponseEntity<>("User Deleted!",HttpStatus.OK);

    }




}

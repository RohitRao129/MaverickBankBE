package com.rohit.springboot.MaverickBank.repository;

import com.rohit.springboot.MaverickBank.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepository extends JpaRepository<User,Long> {

    User findByEmail(String email);
    User findByPan(String pan);
    User findByPhonenumber(String phonenumber);
    User findByEmailOrPhonenumberOrPan(String email,String phonenumber,String pan);

}

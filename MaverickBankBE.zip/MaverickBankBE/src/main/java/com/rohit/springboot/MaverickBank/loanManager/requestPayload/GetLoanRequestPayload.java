package com.rohit.springboot.MaverickBank.loanManager.requestPayload;

import lombok.Data;

@Data
public class GetLoanRequestPayload {
    private Long LoanRequestId;
}

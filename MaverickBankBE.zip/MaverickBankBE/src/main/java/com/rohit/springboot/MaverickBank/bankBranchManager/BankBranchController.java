package com.rohit.springboot.MaverickBank.bankBranchManager;


import com.rohit.springboot.MaverickBank.bankBranchManager.BankBranchDto;
import com.rohit.springboot.MaverickBank.entities.BankBranch;
import com.rohit.springboot.MaverickBank.repository.BankBranchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/branch")
public class BankBranchController {
    @Autowired
    private BankBranchRepository bankBranchRepository;
    @GetMapping("/get")
    public List<BankBranch> getbankbranch(@RequestBody BankBranchDto bankBranchDto){
        return bankBranchRepository.findAllByCityOrIfscOrPincode(bankBranchDto.getCity(), bankBranchDto.getIfsc(), bankBranchDto.getPincode());
    }

    @PostMapping("/add")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<String> addBankBranch(@RequestBody BankBranchDto bankBranchDto){

            if(bankBranchRepository.findByIfsc(bankBranchDto.getIfsc())!=null){
                return  new ResponseEntity<>("ifsc code already registered",HttpStatus.BAD_REQUEST);
            }

            if(bankBranchRepository.findByPincode(bankBranchDto.getPincode())!=null){
                return  new ResponseEntity<>("Another branch present there",HttpStatus.BAD_REQUEST);
            }

            BankBranch newBranch =new BankBranch();
            newBranch.setCity(bankBranchDto.getCity());
            newBranch.setIfsc(bankBranchDto.getIfsc());
            newBranch.setPincode(bankBranchDto.getPincode());

            bankBranchRepository.save(newBranch);

            return new ResponseEntity<>("Bank Added", HttpStatus.OK);

    }


    @PostMapping("/remove")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<String> removeBankBranch(@RequestBody BankBranchDto bankBranchDto){
        BankBranch branch = bankBranchRepository.findByIfsc(bankBranchDto.getIfsc());

        if(branch==null){
            return  new ResponseEntity<>("no branch Found!",HttpStatus.BAD_REQUEST);
        }

        bankBranchRepository.delete(branch);

        return new ResponseEntity<>("Branch removed successfully",HttpStatus.OK);
    }
}

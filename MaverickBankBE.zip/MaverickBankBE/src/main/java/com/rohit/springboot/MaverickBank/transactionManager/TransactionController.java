package com.rohit.springboot.MaverickBank.transactionManager;

import com.rohit.springboot.MaverickBank.entities.Account;
import com.rohit.springboot.MaverickBank.entities.Transaction;
import com.rohit.springboot.MaverickBank.repository.AccountRepository;
import com.rohit.springboot.MaverickBank.repository.BankBranchRepository;
import com.rohit.springboot.MaverickBank.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;
import java.util.Optional;



@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private BankBranchRepository bankBranchRepository;
    @GetMapping("/getall")
    @ResponseBody
    public  List<Transaction> findAllTransactions(){
        return transactionRepository.findAll();
    }

    @PostMapping("/get")
    @ResponseBody
    public ResponseEntity<Transaction> getTransaction(@RequestBody TransactionReqDto req){
        return new ResponseEntity<>((transactionRepository.findById(req.getId()).get()),HttpStatus.OK);
    }

    @PostMapping("/send")
    public ResponseEntity<String> transaction(@RequestBody TransactionReqDto transactionReqDto){

        Transaction transaction =new Transaction();
        transaction.setType('T');
        transaction.setAmount(transactionReqDto.getAmount());

        Account ownerAccount = accountRepository.findById(transactionReqDto.getOwner_account()).get();
        Account receiverAccount = accountRepository.findById(transactionReqDto.getReceiver_account()).get();

        if(ownerAccount==null){
            return  new ResponseEntity<>("transaction can`t be associated to any account",HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if(receiverAccount==null){
            return new ResponseEntity<>("Receiver not Found!", HttpStatus.BAD_REQUEST);
        }

        transaction.setTransaction_owner(ownerAccount);
        transaction.setTransaction_receiver(receiverAccount);

        if(!Objects.equals(transactionReqDto.getPin(), ownerAccount.getPin())){
            return new ResponseEntity<>("Wrong pin", HttpStatus.BAD_REQUEST);
        }

        if(ownerAccount.getBalance()< transactionReqDto.getAmount()){
            return new ResponseEntity<>("Insufficient Funds", HttpStatus.BAD_REQUEST);
        }
        ownerAccount.setBalance(ownerAccount.getBalance() - transactionReqDto.getAmount());

        receiverAccount.setBalance(receiverAccount.getBalance()+ transactionReqDto.getAmount());

        accountRepository.save(ownerAccount);
        accountRepository.save(receiverAccount);
        transactionRepository.save(transaction);
        return  new ResponseEntity<>("transaction successfully",HttpStatus.OK);
    }

    @PostMapping("/deposit")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<?> depositMoney(@RequestBody TransactionReqDto req){
        Transaction transaction =new Transaction();

        transaction.setType('D');
        transaction.setAmount(req.getAmount());
        Account ownerAccount = accountRepository.findById(req.getOwner_account()).get();
        transaction.setTransaction_owner(ownerAccount);
        ownerAccount.setBalance(ownerAccount.getBalance() + req.getAmount());
        transactionRepository.save(transaction);

        return new ResponseEntity<>("Deposit Successfull",HttpStatus.OK);
    }


    @PostMapping("/withdraw")
    @PreAuthorize("hasAnyAuthority('ADMIN','EMPLOYEE')")
    public ResponseEntity<?> withdrawMoney(@RequestBody TransactionReqDto req){
        Account ownerAccount = accountRepository.findById(req.getOwner_account()).get();
        if(ownerAccount.getBalance()<req.getAmount()){
            return new ResponseEntity<>("Low Balance",HttpStatus.BAD_REQUEST);
        }

        Transaction transaction =new Transaction();
        transaction.setType('W');
        transaction.setAmount(req.getAmount());
        transaction.setTransaction_owner(ownerAccount);

        if(!Objects.equals(req.getPin(), ownerAccount.getPin())){
            return new ResponseEntity<>("Wrong pin", HttpStatus.BAD_REQUEST);
        }
        ownerAccount.setBalance(ownerAccount.getBalance() - req.getAmount());
        transactionRepository.save(transaction);

        return new ResponseEntity<>("Withdraw Successfull",HttpStatus.OK);
    }


}

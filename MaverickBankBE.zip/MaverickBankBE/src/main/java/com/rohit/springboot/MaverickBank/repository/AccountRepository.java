package com.rohit.springboot.MaverickBank.repository;

import com.rohit.springboot.MaverickBank.entities.Account;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface AccountRepository extends JpaRepository<Account,Long> {

    List<Account> findAllByIfsc(String ifsc);
}

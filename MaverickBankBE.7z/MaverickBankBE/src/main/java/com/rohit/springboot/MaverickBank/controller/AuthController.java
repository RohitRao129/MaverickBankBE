package com.rohit.springboot.MaverickBank.controller;


import com.rohit.springboot.MaverickBank.dto.LoginDTO;
import com.rohit.springboot.MaverickBank.dto.SignUpDto;
import com.rohit.springboot.MaverickBank.entities.User;
import com.rohit.springboot.MaverickBank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/auth")
public class AuthController {


    @Autowired
    private UserRepository userRepository;

    @PostMapping("/signup")

    public ResponseEntity<?>  addUser(@RequestBody SignUpDto signUpDto){

        User existinguser = userRepository.findByEmail(signUpDto.getEmail());
        if(existinguser!=null){
            return new ResponseEntity<>("Email already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPhonenumber(signUpDto.getPhonenumber());
        if(existinguser!=null){
            return new ResponseEntity<>("Phone already registered",HttpStatus.BAD_REQUEST);
        }
        existinguser = userRepository.findByPan(signUpDto.getPan());
        if(existinguser!=null){
            return new ResponseEntity<>("PAN already registered",HttpStatus.BAD_REQUEST);
        }


        User user = new User();
        user.setFullname(signUpDto.getFullname());
        user.setEmail(signUpDto.getEmail());
        user.setPhonenumber(signUpDto.getPhonenumber());
        user.setPassword(signUpDto.getPassword());
        user.setPan(signUpDto.getPan());
        user.setDob(signUpDto.getDob());
        user.setAddress(signUpDto.getAddress());
        userRepository.save(user);

        return new ResponseEntity<>("User registered successfully", HttpStatus.OK);

    }

    @GetMapping("/getallusers")
    public  List<User> findAllUsers(){
        return userRepository.findAll();
    }


    @ResponseBody
    @PostMapping("/signin")
    public Map<String, String> authenticateUser(@RequestBody LoginDTO loginDto){
        HashMap<String, String> Response = new HashMap<>();

        User user = userRepository.findByEmailOrPhonenumberOrPan(loginDto.getUsername(),loginDto.getUsername(),loginDto.getUsername());
        if(user==null){
            Response.put("success","false");
            Response.put("msg" ,"User Not Found!");
            return  Response;
        }
        if(!Objects.equals(user.getPassword(),loginDto.getPassword())){
            Response.put("success","false");
            Response.put("msg" ,"Incorrect Password!");
            return  Response;
        }

        Response.put("success","true");
        Response.put("msg" ,"Logged In!");
        Response.put("UserId",user.getId().toString());
        return  Response;
    }
}

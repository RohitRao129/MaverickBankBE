package com.rohit.springboot.MaverickBank.controller;

import com.rohit.springboot.MaverickBank.Payload.MakeTransactionDto;
import com.rohit.springboot.MaverickBank.entities.Account;
import com.rohit.springboot.MaverickBank.entities.Transaction;
import com.rohit.springboot.MaverickBank.repository.AccountRepository;
import com.rohit.springboot.MaverickBank.repository.TransactionRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/transaction")
public class TransactionController {

    private TransactionRepository transactionRepository;
    private AccountRepository accountRepository;
    @GetMapping("/getall")
    public  List<Transaction> findAllTransactions(){
        return transactionRepository.findAll();
    }

    @PostMapping("/make")
    public ResponseEntity<String> withdrawMoney(@RequestBody MakeTransactionDto makeTransactionDto){
        Transaction transaction =new Transaction();

        transaction.setType(makeTransactionDto.getType());
        transaction.setAmount(makeTransactionDto.getAmount());

        Optional<Account> ownerAccount = accountRepository.findById(makeTransactionDto.getOwner_account());
        Optional<Account> receiverAccount = accountRepository.findById(makeTransactionDto.getReceiver_account());



        if(ownerAccount.isPresent()){


            if(transaction.getType()=='W' || transaction.getType()=='T'){
                if(ownerAccount.get().getBalance()< makeTransactionDto.getAmount()){
                    return new ResponseEntity<>("Insufficient Funds", HttpStatus.BAD_REQUEST);
                }
                ownerAccount.get().setBalance(ownerAccount.get().getBalance() - makeTransactionDto.getAmount());
            }

            if(transaction.getType()=='T'){

                if(receiverAccount.isEmpty()){
                    return new ResponseEntity<>("Receiver not Found!", HttpStatus.BAD_REQUEST);
                }

                receiverAccount.get().setBalance(receiverAccount.get().getBalance()+ makeTransactionDto.getAmount());
            }

            if(transaction.getType()=='D'){
                ownerAccount.get().setBalance(ownerAccount.get().getBalance() + makeTransactionDto.getAmount());
            }

            transaction.setTransaction_owner(ownerAccount.get());
            transaction.setTransaction_receiver(receiverAccount.get());

        }
        else{
            return  new ResponseEntity<>("transaction can`t be associated to any account",HttpStatus.INTERNAL_SERVER_ERROR);
        }


        return  new ResponseEntity<>("transaction successfully",HttpStatus.OK);
    }




}

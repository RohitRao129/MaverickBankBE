package com.rohit.springboot.MaverickBank.controller;


import com.rohit.springboot.MaverickBank.dto.BankBranchDto;
import com.rohit.springboot.MaverickBank.entities.BankBranch;
import com.rohit.springboot.MaverickBank.repository.BankBranchRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/branch")
public class BankBranchController {

    private BankBranchRepository bankBranchRepository;
    @GetMapping("/get")
    public List<BankBranch> getbankbranch(BankBranchDto bankBranchDto){
        return bankBranchRepository.findAllByCityOrIfsc(bankBranchDto.getCity(), bankBranchDto.getIfsc());
    }

    @PostMapping("/add")
    public ResponseEntity<String> addBankBranch(BankBranchDto bankBranchDto){

            if(bankBranchRepository.findByIfsc(bankBranchDto.getIfsc())!=null){
                return  new ResponseEntity<>("ifsc code already registered",HttpStatus.BAD_REQUEST);
            }

            if(bankBranchRepository.findByPincode(bankBranchDto.getPincode())!=null){
                return  new ResponseEntity<>("Another branch present there",HttpStatus.BAD_REQUEST);
            }

            BankBranch newBranch =new BankBranch();
            newBranch.setCity(bankBranchDto.getCity());
            newBranch.setIfsc(bankBranchDto.getIfsc());
            newBranch.setPincode(bankBranchDto.getPincode());

            bankBranchRepository.save(newBranch);

            return new ResponseEntity<>("Bank Added", HttpStatus.OK);

    }

    @PostMapping("/update")
    public ResponseEntity<String> updateBankBranch(BankBranchDto bankBranchDto){
        Optional<BankBranch> branch = bankBranchRepository.findById(bankBranchDto.getId());
        if(branch.isEmpty()){
            return new ResponseEntity<>("No Bank branch found",HttpStatus.BAD_REQUEST);
        }

        if(!Objects.equals(bankBranchDto.getCity(), "")){
            branch.get().setCity(bankBranchDto.getCity());
        }
        if(!Objects.equals(bankBranchDto.getIfsc(), "")){
            branch.get().setIfsc(bankBranchDto.getIfsc());
        }
        if(!Objects.equals(bankBranchDto.getPincode(), "")){
            branch.get().setPincode(bankBranchDto.getPincode());
        }

        bankBranchRepository.save(branch.get());
        return new ResponseEntity<>("branch updated successfully",HttpStatus.OK);
    }

    @PostMapping("/remove")
    public ResponseEntity<String> removeBankBranch(BankBranchDto bankBranchDto){
        Optional<BankBranch> branch = bankBranchRepository.findById(bankBranchDto.getId());

        if(branch.isEmpty()){
            return  new ResponseEntity<>("no branch Found!",HttpStatus.BAD_REQUEST);
        }

        bankBranchRepository.delete(branch.get());

        return new ResponseEntity<>("Branch removed successfully",HttpStatus.BAD_REQUEST);
    }
}

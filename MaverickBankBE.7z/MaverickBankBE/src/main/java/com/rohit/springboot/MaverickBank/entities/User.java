package com.rohit.springboot.MaverickBank.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="users")
public class User {

    //Identity Generation type means AutoIncrement not supported in oracle DB
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  Long id;

    @Column(nullable = false)
    private String fullname;

    @Column(nullable = false,unique = true)
    private String email;

    @Column(nullable = false,unique = true)
    private String phonenumber;

    @Column(unique = true,length =10)
    private String pan;

    @Column(nullable = false)
    private String address;

    @Column(nullable = false, length = 8)
    private Date dob;

    @Column(nullable = false)
    private String password;

    private Role role;

    @ManyToMany(mappedBy = "account_owners")
    private List<Account> accounts;

    @OneToMany(mappedBy = "approver_id")
    private Set<ApprovedLoan> approvedloans;

}

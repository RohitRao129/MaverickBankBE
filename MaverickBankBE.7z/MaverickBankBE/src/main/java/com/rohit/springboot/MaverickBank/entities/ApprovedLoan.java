package com.rohit.springboot.MaverickBank.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;

import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "approved_loans")
public class ApprovedLoan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @Temporal(TemporalType.DATE)
    @CreatedDate
    private Date startdate;

    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinColumn(name = "borrower_account",nullable = false)
    private Account borrower_account;

    @ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinColumn(name = "approver_id",nullable = false)
    private User approver_id;

    @Column(nullable = false)
    private float amount;

    @Column(nullable = false)
    private Float amountleft;


    @Column(nullable = false)
    private Integer term;

    @Column(nullable = false)
    private float interest;

    @Column(nullable = false)
    private String type;
}

package com.rohit.springboot.MaverickBank.Authentication;

import lombok.*;

@Data
public class LoginResponsePayload {
    private String token;
    private String type = "Bearer";
    private Long id;
    private String email;
    private String roles;

    public LoginResponsePayload(String accessToken, Long id, String email, String roles) {
        this.token = accessToken;
        this.id = id;
        this.email = email;
        this.roles = roles;
    }

}


